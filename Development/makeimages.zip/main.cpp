#include "main.h"

#include <llib/gen/file.h>
#include <llib/gen/stringtools.h>


// Show the usage guide for LXA
void ShowUsage()
{
   puts(LANGUTF8("Usage:"));
   puts(LANGUTF8(" makeimages \"folder to process\"" "output file"));
   puts(LANGUTF8("\nOptional parameters (common)"));
}

uint ProcessImages(LStringLong& slOutput, const tchar* szFolderPath, uint uDepth)
{
   uint uFiles = 0;
   LStringList slstFiles;
   for (LFile::FolderIteratorAllFiles fi(szFolderPath); fi.IsValid(); fi.Next()) {
      if (fi.IsDotFolder() || fi.IsFolder()) continue;
      tchar szExt[LSTR];
      LFile::GetFileExtensionFromPath(szExt, fi.GetFile());
      if (tstricmp(szExt, TEXT(".ini")) == 0 || tstricmp(szExt, TEXT(".db")) == 0) continue;
      tchar szFile[LSTR];
      LFile::GetFileNameFromFile(szFile, fi.GetFile());
      LStringReplaceChar(szFile, TEXT('-'), TEXT('_'));
      slstFiles.Add(szFile);
   }
   slstFiles.SortAscending();

   // bambi9
   // bambi11a
   // bambi11b
   // bambi12ba
   // bambi-pool-sex
   tchar szLastFile[LSTR];
   szLastFile[0] = 0;
   uint uCount = 0;
   for (size_t u = 0; u < slstFiles.GetItemCount(); u++) {
      const tchar* szFile = slstFiles.GetItem(u);
      tchar cLast = szFile[tstrlen(szFile) - 1];

      if (szLastFile[0] == 0) {
         if (cLast < TEXT('a') || cLast > TEXT('z')) {
            for (uint u = 0; u < uDepth; u++) slOutput.Append(TEXT("\t"));
            tsprintfappend(slOutput, TEXT("%s: 0,\r\n"), szFile);
            continue;
         }
         uCount++;
         tstrcpy(szLastFile, szFile);
         if (cLast != TEXT('a')) {
            for (uint u = 0; u < uDepth; u++) slOutput.Append(TEXT("\t"));
            tsprintfappend(slOutput, TEXT("%s: 0,\r\n"), szFile);
         }
         continue;
      }

      tchar cLastLast = szLastFile[tstrlen(szLastFile) - 1];
      if ((cLast < TEXT('a') || cLast > TEXT('z')) || (tstrncmp(szFile, szLastFile, tstrlen(szFile) - 1) != 0) || (uint(cLast) != uint(cLastLast + 1))) {

         if (uCount == 1) {
            if (cLast == TEXT('a')) {
               tstrcpy(szLastFile, szFile);
               uCount = 1;
            } else {
               uCount = 0;
               szLastFile[0] = 0;
               for (uint u = 0; u < uDepth; u++) slOutput.Append(TEXT("\t"));
               tsprintfappend(slOutput, TEXT("%s: 0,\r\n"), szFile);
            }
            continue;
         }
         tchar szFileMod[LSTR];
         tstrcpy(szFileMod, szLastFile);
         szFileMod[tstrlen(szLastFile) - 1] = 0;
         for (uint u = 0; u < uDepth; u++) slOutput.Append(TEXT("\t"));
         tsprintfappend(slOutput, TEXT("%s: %u,\r\n"), szFileMod, uCount);

         if (cLast < TEXT('a') || cLast > TEXT('z')) {
            uCount = 0;
            szLastFile[0] = 0;
            for (uint u = 0; u < uDepth; u++) slOutput.Append(TEXT("\t"));
            tsprintfappend(slOutput, TEXT("%s: 0,\r\n"), szFile);
         } else if (cLast == TEXT('a')) {
            tstrcpy(szLastFile, szFile);
            uCount = 1;
         } else {
            uCount = 0;
            szLastFile[0] = 0;
            for (uint u = 0; u < uDepth; u++) slOutput.Append(TEXT("\t"));
            tsprintfappend(slOutput, TEXT("%s: 0,\r\n"), szFile);
         }
         uFiles++;
      } else {
         tstrcpy(szLastFile, szFile);
         uCount++;
      }
   }
   if (szLastFile[0] != 0) {
      if (uCount > 0) {
         tchar szFileMod[LSTR];
         tstrcpy(szFileMod, szLastFile);
         szFileMod[tstrlen(szLastFile) - 1] = 0;
         for (uint u = 0; u < uDepth; u++) slOutput.Append(TEXT("\t"));
         tsprintfappend(slOutput, TEXT("%s: %u,\r\n"), szFileMod, uCount);
      } else {
         for (uint u = 0; u < uDepth; u++) slOutput.Append(TEXT("\t"));
         tsprintfappend(slOutput, TEXT("%s: 0,\r\n"), szLastFile);
      }
      uFiles++;
   }
   return uFiles;
}

uint ProcessDress(LStringLong& slOutput, const tchar* szFolderPath, const tchar* szFolder, const tchar* szPersonFolderPath, uint uDepth)
{
   LStringLong slDressOutput;
   for (uint u = 0; u < uDepth; u++) slDressOutput.Append(TEXT("\t"));

   if (uDepth > 0) slDressOutput.tsprintfappend(TEXT("%s: {\r\n"), szFolder);

   uint uFiles = ProcessImages(slDressOutput, szFolderPath, uDepth + 1);
   uint uFilesNow = uFiles;

   uint uDresses = 0;
   // Do any dresses
   for (LFile::FolderIteratorAllFiles fi(szFolderPath); fi.IsValid(); fi.Next()) {
      if (fi.IsDotFolder() || !fi.IsFolder()) continue;
      if (tstrcmp(fi.GetFile(), TEXT("Explicit")) == 0) continue;
      tchar szFolder[LSTR];
      LFile::MakeFilePath(szFolder, szFolderPath, fi.GetFile());
      uint uDressFiles = ProcessDress(slDressOutput, szFolder, fi.GetFile(), szFolderPath, uDepth + 1);
      uFiles += uDressFiles;
      if (uDressFiles > 0) uDresses++;
   }
   if (uDresses > 0) {
      slDressOutput.SetLength(slDressOutput.GetLength() - 3);
   }

   // Process Explicit folder if present
   bool bExplicit = false;
   if (szPersonFolderPath != nullptr) {
      tchar szExplicitFolder[LSTR];
      LFile::MakeFilePath(szExplicitFolder, szPersonFolderPath, TEXT("Explicit"));
      if (LFile::TestFolderExists(szExplicitFolder)) {
         LStringLong slExplicitOutput;
         uint uDressFiles = ProcessDress(slExplicitOutput, szExplicitFolder, TEXT("Explicit"), nullptr, uDepth + 1);
         uFiles += uDressFiles;
         if (uDressFiles > 0) {
            bExplicit = true;
            if (uDresses > 0) slDressOutput.Append(TEXT(",\r\n"));
            slExplicitOutput.SetLength(slExplicitOutput.GetLength() - 3);
            slExplicitOutput.Append(TEXT("\r\n"));
            slDressOutput.Append(slExplicitOutput);
         } else if (uDresses > 0) slDressOutput.Append(TEXT("\r\n"));
      }
   } else if (uDresses > 0) slDressOutput.Append(TEXT("\r\n"));

   if (uFiles > 0) {
      if (uFiles == uFilesNow) {
         slDressOutput.SetLength(slDressOutput.GetLength() - 3);
         slDressOutput.Append(TEXT("\r\n"));
      }
      for (uint u = 0; u < uDepth; u++) slDressOutput.Append(TEXT("\t"));
      if (uDepth > 0) slDressOutput.Append(TEXT("},\r\n"));
      slOutput.Append(slDressOutput);
   }
   return uFiles;
}

void ProcessPerson(LWriteFile& wf, const tchar* szFolderPath, const tchar* szFolder)
{
   fprintfUTF8(wf, TEXT("%s: {\r\n"), szFolder);

   LStringLong slOutput;

   uint uLocales = 0;
   // Do any dresses
   for (LFile::FolderIteratorAllFiles fi(szFolderPath); fi.IsValid(); fi.Next()) {
      if (fi.IsDotFolder()) continue;
      if ((tstrcmp(fi.GetFile(), TEXT("UK")) != 0) && (tstrcmp(fi.GetFile(), TEXT("US")) != 0)) continue;
      tchar szFolder[LSTR];
      LFile::MakeFilePath(szFolder, szFolderPath, fi.GetFile());
      uint uDressFiles = ProcessDress(slOutput, szFolder, fi.GetFile(), szFolder, 1);
      if (uDressFiles > 0) uLocales++;
   }
   if (uLocales == 0) ProcessDress(slOutput, szFolderPath, szFolder, szFolderPath, 0);
  
   wf.WriteString(slOutput.c_str());

   wf.WriteString(TEXT("},\r\n"));
}

//lint -e{818} Suppress warning
int __cdecl main(int argc, char* argv[])
{
   if (argc < 2) {
      ShowUsage();
      return EXIT_FAILURE;
   } else if ((tstricmp(argv[1], "--help") == 0) || (tstricmp(argv[1], "-help") == 0)) {
      ShowUsage();
      return EXIT_SUCCESS;
   }

   tchar szFolder[LSTR];
   szFolder[0] = 0;
   if (argc >= 1) LCopyFromUTF8(szFolder, argv[1]);
   tchar szOutput[LSTR];
   szOutput[0] = 0;
   if (argc >= 2) LCopyFromUTF8(szOutput, argv[2]);

   // Process Commandline parameters
   for (int i = 1; i < argc; i++) {

      const char* szArg = argv[i];
      if ((strcmp(szArg, "-folder") == 0)) {
         // Set the input folder
         i++;
         if (i < argc) LCopyFromUTF8(szFolder, argv[i]);
      }
      if ((strcmp(szArg, "-output") == 0)) {
         // Set the input folder
         i++;
         if (i < argc) LCopyFromUTF8(szOutput, argv[i]);
      }
   }

   LWriteFile wf(szOutput, 5000);

   for (LFile::FolderIteratorAllFiles fi(szFolder); fi.IsValid(); fi.Next()) {
      if (fi.IsDotFolder()) continue;
      tchar szThisFolder[LSTR];
      LFile::MakeFilePath(szThisFolder, szFolder, fi.GetFile());
      if (fi.IsFolder()) ProcessPerson(wf, szThisFolder, fi.GetFile());
   }

   wf.Close();

   return 0;
}
