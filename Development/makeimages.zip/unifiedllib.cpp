// LLib .cpp files.
// Included here to simplify project maintenance and speed up compile times.
// See 'Unified .cpp Files' in SourceCode/llib/documentation/building.html

#include <llib/gen/llibbase.h>

#ifdef __WIN__
// Any header files which call DEFINE_GUID() need to be included before any
// .cpp files have a chance to include <initguid.h>.
// e.g., #include <llib/snd/wavheader.h>
#endif // __WIN__

#include "../llib/gen/appsettings.cpp"
#include "../llib/gen/charsets.cpp"
#include "../llib/gen/debug.cpp"
#include "../llib/gen/file.cpp"
#include "../llib/gen/llibbase.cpp"
#include "../llib/gen/mutex.cpp"
#include "../llib/gen/process.cpp"
#include "../llib/gen/stringtools.cpp"
#include "../llib/gen/unittest.cpp"
