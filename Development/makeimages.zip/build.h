// build.h
// (c) LLib Source Code Trust. All rights reserved.
//
// Collects together all definitions which may be used in any source file, in
// LLib or the application.
//
// Note that new build flags should be added to lxa.lxa using <define> tags,
// instead of using #defines here, to allow the flags to affect LXA dialogs,
// help files, etc..

#ifndef build_h
#define build_h

#include <lxa/lxabuild.h>     // For the #defines created by LXA <define> tags

#endif // !build_h
