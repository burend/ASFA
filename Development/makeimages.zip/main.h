// Main entry point
// (c) LLib Source Code Trust. All rights reserved.

#pragma once

#include <llib/gen/llibbase.h>

int __cdecl main(int argc, char* argv[]);
